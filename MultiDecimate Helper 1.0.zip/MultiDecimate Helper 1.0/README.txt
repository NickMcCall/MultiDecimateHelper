MultiDecimate Helper by Nicholas McCall, 2018

A program to manually edit the results of MultiDecimate, MDEC2, and compatible scripts.

To use, run Pass 1 of MultiDecimate and then, MultiDecimate.exe, as usual. Place MultiDecimateHelper.jar in the same folder as mfile.txt.

Run MultiDecimate Helper:
- Open cfile.txt. It will display on the right side of the screen. Frames marked for deletion will be in red.
- To mark/unmark frames for deletion, either double-click on a frame, or select and press <Enter>.
- Save. This will also produce a new dfile.txt. Both cfile and dfile will be overwritten.

Once finished with MultiDecimate Helper, run Pass 2 of MultiDecimate.